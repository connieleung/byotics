# reveal-code-focus

A [Reveal.js](https://github.com/hakimel/reveal.js) plugin that allows focusing
on specific lines of code blocks.

## Usage

[View the live demo.](https://d10.github.io/reveal-code-focus)

## Author

| [![twitter/demoneaux](http://gravatar.com/avatar/029b19dba521584d83398ada3ecf6131?s=70)](https://twitter.com/demoneaux "Follow @demoneaux on Twitter") |
|---|
| [Benjamin Tan](http://d10.github.io/) |

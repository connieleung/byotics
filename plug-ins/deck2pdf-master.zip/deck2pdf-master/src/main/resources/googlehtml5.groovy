// profile for html5slides (http://html5slides.googlecode.com/)

isLastSlide= {
    js 'curSlide == slideEls.length-1'
}

nextSlide= {
    js 'nextSlide();'
}

isLastSlide = {
    js 'window.slideshow.getCurrentSlideIndex() >= window.slideshow.getSlideCount() - 1;'
}

nextSlide = {
    js 'window.slideshow.gotoNextSlide();'
}
